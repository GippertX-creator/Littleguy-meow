# 照片对 V0.2 的具体帮助

原始照片基于提交 `1a56c5832c7bf8d843c605ce1b3ea2eedc79b515`，共 35 张。表中编号是完整文件名 `微信图片_日期时间_编号_52` 中的编号，目录为仓库 `pic/`。编号只用于索引，不据此推定动作的时间顺序。

## 身份与比例

| 原图 | 可直接参考的内容 | 在 V0.2 中的用途 |
| --- | --- | --- |
| [401 清晰正脸](https://github.com/GippertX-creator/Littleguy-meow/blob/main/pic/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20261030144217_401_52.jpg) | 眼距、眼缘、粉鼻子、口鼻、额头纹、耳朵与脸颊 | 所有朝向都保留同一张脸，不在走路时换成别的猫 |
| [404 正面全身](https://github.com/GippertX-creator/Littleguy-meow/blob/main/pic/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20261030144222_404_52.jpg) | 前腿长度、胸宽、尾巴与身长 | 起身后不缩腿、不突然变胖 |
| [418 侧向坐姿](https://github.com/GippertX-creator/Littleguy-meow/blob/main/pic/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20261030144246_418_52.jpg) | 头部侧面、颈胸关系、背线与尾尖 | 站立、斜向走动、回头的造型依据 |
| [423 背毛](https://github.com/GippertX-creator/Littleguy-meow/blob/main/pic/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20261030144255_423_52.jpg) | 灰金毛尖层次、细毛流、颈背和耳缘 | 背向行走也保留灰背，转身时毛色不突变 |
| [399 背部侧躺](https://github.com/GippertX-creator/Littleguy-meow/blob/main/pic/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20261030144033_399_52.jpg) | 躯干长度、完整尾部、灰背至浅腹的过渡 | 腰胯弯曲和尾巴摆动的外观校准 |

主人明确要求毛更亮、更长，身体不要像最初草稿一样肥大。外层毛的轻微蓬松和尾巴毛量不能用扩大躯干骨架代替。提亮需保留灰色毛尖，不把灰金整体染成橙黄。眼睛不再额外卡通放大。

## 休息照片可以拆出的动作

| 原图 | 观察到的姿态 | 可以发展出的版本动作 |
| --- | --- | --- |
| [415 揣手](https://github.com/GippertX-creator/Littleguy-meow/blob/main/pic/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20261030144239_415_52.jpg) | 低趴、前爪收在胸前，重心很稳 | 小面包、缓慢露出一只前爪、准备起身 |
| [397 团着睡](https://github.com/GippertX-creator/Littleguy-meow/blob/main/pic/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20261030144009_397_52.jpg) | 身体弯成团，头低、尾巴沿着身体 | C 形蜷睡、从蜷睡抬头、舒展腰胯 |
| [398 睡脸与前爪](https://github.com/GippertX-creator/Littleguy-meow/blob/main/pic/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20261030144024_398_52.jpg) | 脸侧压低、前爪聚在脸前，躯干被画面裁切 | 枕爪睡、爪子遮脸；完整身体需要参考别的照片补足 |
| [407 侧躺抬头](https://github.com/GippertX-creator/Littleguy-meow/blob/main/pic/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20261030144225_407_52.jpg) | 一边前肘支起、另一前肢伸出，后腿侧放 | 抬头听动静、侧躺看光标、懒懒伸爪 |
| [417 半眯眼侧卧](https://github.com/GippertX-creator/Littleguy-meow/blob/main/pic/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20261030144244_417_52.jpg) | 身体侧放，前爪在胸前，头仍支起 | 侧躺打盹、从侧卧转向腹趴 |
| [411 枕着拖鞋](https://github.com/GippertX-creator/Littleguy-meow/blob/main/pic/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20261030144233_411_52.jpg) 与 [412 转头](https://github.com/GippertX-creator/Littleguy-meow/blob/main/pic/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20261030144235_412_52.jpg) | 头部由低位到另一朝向的两个静态状态 | 可作头部抬起/转向的形态参考；速度和中间运动不能从两张照片直接确定 |
| [396 全身伸长](https://github.com/GippertX-creator/Littleguy-meow/blob/main/pic/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20261030143846_396_52.jpg) | 猫正躺在地上，前肢向头顶方向伸长、后肢向另一端舒展 | 长条侧躺、伸爪、醒来伸展；不是四足站立或迈步照片 |
| [416 一爪伸出露肚](https://github.com/GippertX-creator/Littleguy-meow/blob/main/pic/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20261030144240_416_52.jpg) | 侧仰、肚皮暴露、一只前爪伸向侧方 | 侧仰抬爪、伸懒腰后翻回侧躺 |
| [422 仰躺伸长](https://github.com/GippertX-creator/Littleguy-meow/blob/main/pic/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20261030144252_422_52.jpg) | 长躯干、四肢放松、腹毛完整 | 仰躺时保留身长，不把身体压成圆球 |
| [429 抬双爪](https://github.com/GippertX-creator/Littleguy-meow/blob/main/pic/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20261030144314_429_52.jpg) | 仰躺，前爪抬向观察者，后腿放松 | 躺着抱空气、双爪拍光标、假装抱住玩具 |
| [420 半侧倚](https://github.com/GippertX-creator/Littleguy-meow/blob/main/pic/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20261030144249_420_52.jpg) | 躯干侧倚、后肢向一边展开，头仍然抬着 | 走累后先坐歪，再慢慢侧躺的中间姿势 |
| [424 窗台打哈欠](https://github.com/GippertX-creator/Littleguy-meow/blob/main/pic/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20261030144258_424_52.jpg) | 趴在窗台，前爪垂在台面边缘外 | 打哈欠和放松前爪；在平地版本里改为爪子向前落地，不能无支撑悬挂 |

408、409、414、426、427、428 也提供不同角度的露肚和四肢姿态，可用于检查翻身时的轮廓、关节和浅色腹毛。视频通话截图 402、403、425 适合表情参考，手和遮挡区域不能直接成为身体纹理。

## 站立与步态的证据边界

目前素材以坐姿、卧姿和仰躺为主，没有足够的连续侧面行走序列，也没有完整的小跳起落记录。404、418、419 可确定腿长和大体比例，不能直接给出四足承重的全部关节位置。

因此，12 种站姿和连续步态都标为“根据体型补充设计”。先用同一骨架建立四足承重，再把照片中的脸、毛色和身长映射过去。396 是躺着伸长的照片，不能当作腾空跳跃或走路帧。所有新动作需要检查爪、肘、肩、髋、膝和尾根，不能靠照片之间简单变形。

素材不是严格标定的多视角扫描；毛发遮挡下的身体深度、背面隐藏纹理及真实步态节奏仍有推演部分。此限制不阻止制作下一版，但应以角色一致性和动画验收来约束补充内容。

## 动作生成和校准顺序

1. 锁定 401 的正脸、404 的比例和 423 的灰背，制作同一套六方向标准造型。
2. 根据照片确认卧姿大类，按目录补充四肢摆放差异；每个新增姿势记录观察或设计依据。
3. 为四足站、慢走和小跳建立可复用的承重关系和过渡骨架，再覆盖外观。
4. 检查两侧毛色、腿长、头身比例和尾巴，去掉多肢、爪子融合、毛色漂移和形体忽胖忽瘦。
5. 关键姿势通过后才制作连续片段、裁切透明图集并校准脚底锚点；概念板不会直接当运行图集。
